#!/bin/bash
set -eu
export WAYLAND_DISPLAY=wayland-tray-lab
export GDK_BACKEND=wayland
export CODEXHUB_RUNTIME_HOME=/tmp/codexhub-tray-lab/user/app-runtime
export CODEXHUB_RESOURCE_ROOT=/mnt
mkdir -p "$CODEXHUB_RUNTIME_HOME/proxy"
printf '%s\n' '{"auto_start_software":false,"auto_start_gateway":false}' > "$CODEXHUB_RUNTIME_HOME/proxy/settings.json"
for attempt in {1..30}; do test -S "$XDG_RUNTIME_DIR/$WAYLAND_DISPLAY" && break; sleep 1; done
sleep 3
/tmp/codexhub-tray-lab/reference > /tmp/codexhub-tray-lab/artifacts/reference.log 2>&1 &
/mnt/src-tauri/target/release/codexhub > /tmp/codexhub-tray-lab/artifacts/app.log 2>&1 &
wait
