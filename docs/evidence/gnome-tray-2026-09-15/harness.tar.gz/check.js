import GLib from 'gi://GLib';
import System from 'system';
const data=JSON.parse(new TextDecoder().decode(GLib.file_get_contents(ARGV[0])[1]));
function luminance(hex) {
 const c=[1,3,5].map(p=>parseInt(hex.slice(p,p+2),16)/255).map(v=>v<=0.04045?v/12.92:((v+0.055)/1.055)**2.4);
 return c[0]*0.2126+c[1]*0.7152+c[2]*0.0722;
}
let ok=data.length===2 && data.some(m=>m.id.includes("codexhub")) && data.some(m=>m.id.includes("tray_reference"));
for(const menu of data) {
 const target=menu.id.includes('codexhub')?'Show CodexHub':'Show Reference';
 const labels=menu.items.map(i=>i.text);
 const ratios=menu.items.map(i=>{let a=luminance(i.fg),b=luminance(i.bg);return (Math.max(a,b)+0.05)/(Math.min(a,b)+0.05)});
 const pass=labels.includes(target)&&labels.every(Boolean)&&ratios.every(r=>r>=4.5);
 print(JSON.stringify({target,pass,labels,minContrast:Math.min(...ratios)}));
 ok=ok&&pass;
}
System.exit(ok?0:1);
