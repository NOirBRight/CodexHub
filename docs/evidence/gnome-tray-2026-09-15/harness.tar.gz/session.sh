#!/bin/bash
set -eu
export XDG_RUNTIME_DIR=/tmp/codexhub-tray-lab/runtime
export XDG_CONFIG_HOME=/tmp/codexhub-tray-lab/user/config
export XDG_DATA_HOME=/tmp/codexhub-tray-lab/user/data
export XDG_CACHE_HOME=/tmp/codexhub-tray-lab/user/cache
export XDG_CURRENT_DESKTOP=ubuntu:GNOME
export LIBGL_ALWAYS_SOFTWARE=1
unset DISPLAY WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS SESSION_MANAGER
exec dbus-run-session --config-file=/tmp/codexhub-tray-lab/bus.conf -- bash /tmp/codexhub-tray-lab/desktop.sh
