#!/bin/bash
set -eu
pkill -x codexhub || true
export WAYLAND_DISPLAY=wayland-tray-lab GDK_BACKEND=wayland
export CODEXHUB_RUNTIME_HOME=/tmp/codexhub-tray-lab/user/app-runtime CODEXHUB_RESOURCE_ROOT=/mnt
exec /mnt/src-tauri/target/release/codexhub >> /tmp/codexhub-tray-lab/artifacts/restarts.log 2>&1
